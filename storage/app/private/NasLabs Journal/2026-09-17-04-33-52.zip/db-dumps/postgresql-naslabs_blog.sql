--
-- PostgreSQL database dump
--

\restrict CGpvFeLPhgiEbDHr3S43f6C3V0D3pDHBu0bhKOqc5oOgwGLzHMWpwuHWwTE1DGU

-- Dumped from database version 18.4 (Homebrew)
-- Dumped by pg_dump version 18.4 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_tokens; Type: TABLE; Schema: public; Owner: naslabs
--

CREATE TABLE public.api_tokens (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token_hash character varying(64) NOT NULL,
    abilities json NOT NULL,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    service_account_id bigint,
    token_prefix character varying(16)
);


ALTER TABLE public.api_tokens OWNER TO naslabs;

--
-- Name: api_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: naslabs
--

CREATE SEQUENCE public.api_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_tokens_id_seq OWNER TO naslabs;

--
-- Name: api_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: naslabs
--

ALTER SEQUENCE public.api_tokens_id_seq OWNED BY public.api_tokens.id;


--
-- Name: article_tag; Type: TABLE; Schema: public; Owner: naslabs
--

CREATE TABLE public.article_tag (
    article_id bigint NOT NULL,
    tag_id bigint NOT NULL
);


ALTER TABLE public.article_tag OWNER TO naslabs;

--
-- Name: articles; Type: TABLE; Schema: public; Owner: naslabs
--

CREATE TABLE public.articles (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    category_id bigint,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    excerpt character varying(300),
    content text NOT NULL,
    cover_image character varying(255),
    status character varying(255) DEFAULT 'draft'::character varying NOT NULL,
    published_at timestamp(0) without time zone,
    meta_title character varying(255),
    meta_description character varying(300),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    cover_image_alt character varying(255),
    review_requested_at timestamp(0) without time zone,
    scheduled_at timestamp(0) without time zone,
    origin_service_account_id bigint,
    review_status character varying(255) DEFAULT 'none'::character varying NOT NULL,
    reviewed_by bigint,
    reviewed_at timestamp(0) without time zone,
    canonical_url character varying(255),
    og_image character varying(255),
    robots_index boolean DEFAULT true NOT NULL,
    deleted_at timestamp(0) without time zone
);


ALTER TABLE public.articles OWNER TO naslabs;

--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: naslabs
--

CREATE SEQUENCE public.articles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.articles_id_seq OWNER TO naslabs;

--
-- Name: articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: naslabs
--

ALTER SEQUENCE public.articles_id_seq OWNED BY public.articles.id;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: naslabs
--

CREATE TABLE public.audit_logs (
    id bigint NOT NULL,
    user_id bigint,
    event character varying(255) NOT NULL,
    subject_type character varying(255),
    subject_id bigint,
    properties json,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    actor_type character varying(255),
    actor_name character varying(255),
    description text
);


ALTER TABLE public.audit_logs OWNER TO naslabs;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: naslabs
--

CREATE SEQUENCE public.audit_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO naslabs;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: naslabs
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: categories; Type: TABLE; Schema: public; Owner: naslabs
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.categories OWNER TO naslabs;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: naslabs
--

CREATE SEQUENCE public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO naslabs;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: naslabs
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: naslabs
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO naslabs;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: naslabs
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO naslabs;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: naslabs
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: naslabs
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO naslabs;

--
-- Name: service_accounts; Type: TABLE; Schema: public; Owner: naslabs
--

CREATE TABLE public.service_accounts (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    description text,
    content_user_id bigint NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.service_accounts OWNER TO naslabs;

--
-- Name: service_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: naslabs
--

CREATE SEQUENCE public.service_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_accounts_id_seq OWNER TO naslabs;

--
-- Name: service_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: naslabs
--

ALTER SEQUENCE public.service_accounts_id_seq OWNED BY public.service_accounts.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: naslabs
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id bigint,
    ip_address character varying(45),
    user_agent text,
    payload text NOT NULL,
    last_activity integer NOT NULL
);


ALTER TABLE public.sessions OWNER TO naslabs;

--
-- Name: site_settings; Type: TABLE; Schema: public; Owner: naslabs
--

CREATE TABLE public.site_settings (
    id bigint NOT NULL,
    key character varying(255) NOT NULL,
    value text,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.site_settings OWNER TO naslabs;

--
-- Name: site_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: naslabs
--

CREATE SEQUENCE public.site_settings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.site_settings_id_seq OWNER TO naslabs;

--
-- Name: site_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: naslabs
--

ALTER SEQUENCE public.site_settings_id_seq OWNED BY public.site_settings.id;


--
-- Name: tags; Type: TABLE; Schema: public; Owner: naslabs
--

CREATE TABLE public.tags (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.tags OWNER TO naslabs;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: naslabs
--

CREATE SEQUENCE public.tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tags_id_seq OWNER TO naslabs;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: naslabs
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: naslabs
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone,
    role character varying(255) DEFAULT 'editor'::character varying NOT NULL,
    avatar_path character varying(255)
);


ALTER TABLE public.users OWNER TO naslabs;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: naslabs
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO naslabs;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: naslabs
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: api_tokens id; Type: DEFAULT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.api_tokens ALTER COLUMN id SET DEFAULT nextval('public.api_tokens_id_seq'::regclass);


--
-- Name: articles id; Type: DEFAULT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.articles ALTER COLUMN id SET DEFAULT nextval('public.articles_id_seq'::regclass);


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: service_accounts id; Type: DEFAULT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.service_accounts ALTER COLUMN id SET DEFAULT nextval('public.service_accounts_id_seq'::regclass);


--
-- Name: site_settings id; Type: DEFAULT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.site_settings ALTER COLUMN id SET DEFAULT nextval('public.site_settings_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: api_tokens; Type: TABLE DATA; Schema: public; Owner: naslabs
--

COPY public.api_tokens (id, user_id, name, token_hash, abilities, last_used_at, expires_at, created_at, updated_at, service_account_id, token_prefix) FROM stdin;
\.


--
-- Data for Name: article_tag; Type: TABLE DATA; Schema: public; Owner: naslabs
--

COPY public.article_tag (article_id, tag_id) FROM stdin;
1	1
1	6
2	3
2	4
2	5
3	2
3	6
4	1
4	6
5	1
5	5
6	4
6	3
7	5
7	3
\.


--
-- Data for Name: articles; Type: TABLE DATA; Schema: public; Owner: naslabs
--

COPY public.articles (id, user_id, category_id, title, slug, excerpt, content, cover_image, status, published_at, meta_title, meta_description, created_at, updated_at, cover_image_alt, review_requested_at, scheduled_at, origin_service_account_id, review_status, reviewed_by, reviewed_at, canonical_url, og_image, robots_index, deleted_at) FROM stdin;
3	1	3	PostgreSQL: Mulai dari Schema yang Sederhana	postgresql-mulai-dari-schema-yang-sederhana	Cara memodelkan artikel, kategori, dan tag tanpa menambah abstraksi sebelum waktunya.	# Schema yang cukup\n\nUntuk blog personal, tiga tabel inti sudah cukup: `articles`, `categories`, dan `tags`, dengan pivot `article_tag`.\n\nRelasi yang eksplisit membuat query tetap mudah dibaca. Optimasi seperti search engine atau repository layer bisa ditambahkan ketika kebutuhan nyata muncul.	covers/postgresql.png	published	2026-09-05 07:16:44	PostgreSQL: Mulai dari Schema yang Sederhana	Cara memodelkan artikel, kategori, dan tag tanpa menambah abstraksi sebelum waktunya.	2026-09-13 17:15:53	2026-09-14 07:16:44	\N	\N	\N	\N	none	\N	\N	\N	\N	t	\N
4	1	4	Markdown sebagai Format Konten yang Tahan Lama	markdown-sebagai-format-konten-yang-tahan-lama	Mengapa plain text dan Markdown cocok untuk knowledge base yang ingin tetap portabel.	# Konten yang portabel\n\nMarkdown mudah dibaca manusia, mudah disimpan di PostgreSQL, dan tidak mengunci tulisan pada editor tertentu.\n\nRenderer tetap harus menghapus raw HTML dan menolak unsafe link agar konten yang ditampilkan tetap aman.	covers/engineering-journal.png	published	2026-09-05 07:16:44	Markdown sebagai Format Konten yang Tahan Lama	Mengapa plain text dan Markdown cocok untuk knowledge base yang ingin tetap portabel.	2026-09-13 17:15:53	2026-09-14 07:16:44	\N	\N	\N	\N	none	\N	\N	\N	\N	t	\N
5	1	1	Eksperimen: Menambahkan RSS dan Sitemap	eksperimen-menambahkan-rss-dan-sitemap	Draft eksperimen untuk memastikan artikel mudah ditemukan crawler dan dibaca dari feed reader.	# RSS dan sitemap\n\nArtikel yang baik perlu bisa ditemukan. Sitemap membantu crawler memahami URL canonical, sementara RSS memberi pembaca cara mengikuti tulisan baru.\n\n> Ini masih draft eksperimen untuk validasi format dan metadata.	covers/postgresql.png	draft	\N	Eksperimen: Menambahkan RSS dan Sitemap	Draft eksperimen untuk memastikan artikel mudah ditemukan crawler dan dibaca dari feed reader.	2026-09-13 17:15:53	2026-09-14 07:16:44	\N	\N	\N	\N	none	\N	\N	\N	\N	t	\N
1	1	1	Membangun Personal Engineering Journal dengan Laravel	membangun-personal-engineering-journal-dengan-laravel	Catatan arsitektur sederhana untuk blog teknis yang cepat, mudah dirawat, dan nyaman dikembangkan.	# Kenapa engineering journal?\n\nMenulis membuat keputusan teknis lebih mudah ditinjau ulang. Blog ini menggunakan Laravel monolith dengan Blade untuk halaman public dan Livewire untuk dashboard.\n\n## Prinsip awal\n\n- Server-rendered untuk SEO dan performa\n- Markdown sebagai source of truth\n- Action class untuk business operation\n- PostgreSQL sebagai database utama\n\nTargetnya bukan sistem paling kompleks, tetapi sistem yang bisa terus dipakai dan dirawat.	covers/engineering-journal.png	published	2026-09-08 07:16:44	Membangun Personal Engineering Journal dengan Laravel	Catatan arsitektur sederhana untuk blog teknis yang cepat, mudah dirawat, dan nyaman dikembangkan.	2026-09-13 17:15:53	2026-09-14 07:16:44	\N	\N	\N	\N	none	\N	\N	\N	\N	t	\N
2	1	2	Menyiapkan Homelab Kecil yang Bisa Dipantau	menyiapkan-homelab-kecil-yang-bisa-dipantau	Beberapa pelajaran dari mengubah mini PC bekas menjadi server rumahan yang terukur.	# Homelab yang pragmatis\n\nHomelab yang baik tidak harus mahal. Yang penting adalah mengetahui apa yang berjalan, kapan rusak, dan bagaimana memulihkannya.\n\n## Baseline\n\nSaya mulai dari Docker Compose, backup terjadwal, dan monitoring CPU, memory, disk, serta uptime. Setelah baseline stabil, barulah menambah service baru.	covers/homelab.png	published	2026-09-12 07:16:44	Menyiapkan Homelab Kecil yang Bisa Dipantau	Beberapa pelajaran dari mengubah mini PC bekas menjadi server rumahan yang terukur.	2026-09-13 17:15:53	2026-09-14 07:16:44	\N	\N	\N	\N	none	\N	\N	\N	\N	t	\N
6	1	2	Docker Compose sebagai Baseline untuk Service Homelab	docker-compose-sebagai-baseline-untuk-service-homelab	Membuat stack homelab mudah dijalankan ulang melalui konfigurasi yang kecil, terdokumentasi, dan bisa diaudit.	# Docker Compose sebagai baseline\n\nDocker Compose bukan jawaban untuk semua masalah, tetapi ia memberi baseline yang baik untuk service rumahan: deklaratif, mudah dibaca, dan cepat dipulihkan.\n\n## Checklist\n\n- Gunakan volume yang jelas\n- Pisahkan secret dari file Compose\n- Dokumentasikan port dan health check\n- Uji restore sebelum service bertambah banyak\n	covers/homelab.png	published	2026-09-11 13:03:52	Docker Compose sebagai Baseline untuk Service Homelab	Membuat stack homelab mudah dijalankan ulang melalui konfigurasi yang kecil, terdokumentasi, dan bisa diaudit.	2026-09-15 13:03:52	2026-09-15 13:03:52	\N	\N	\N	\N	none	\N	\N	\N	\N	t	\N
7	1	1	Membuat Observability yang Berguna untuk Server Kecil	membuat-observability-yang-berguna-untuk-server-kecil	Mulai dari signal yang tepat: uptime, disk, memory, backup, dan alert yang benar-benar dapat ditindaklanjuti.	# Observability yang berguna\n\nObservability untuk homelab tidak perlu kompleks. Mulai dari beberapa signal yang dapat menjawab pertanyaan operasional paling penting.\n\n## Signal awal\n\n1. Apakah service dapat dijangkau?\n2. Apakah disk dan memory mendekati batas?\n3. Apakah backup terakhir berhasil?\n4. Apakah alert memiliki tindakan yang jelas?\n	covers/engineering-journal.png	published	2026-09-08 13:03:52	Membuat Observability yang Berguna untuk Server Kecil	Mulai dari signal yang tepat: uptime, disk, memory, backup, dan alert yang benar-benar dapat ditindaklanjuti.	2026-09-15 13:03:52	2026-09-15 13:03:52	\N	\N	\N	\N	none	\N	\N	\N	\N	t	\N
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: naslabs
--

COPY public.audit_logs (id, user_id, event, subject_type, subject_id, properties, created_at, updated_at, actor_type, actor_name, description) FROM stdin;
1	1	user.created	App\\Models\\User	2	{"email":"openclaw@naslabs.my.id","role":"editor"}	2026-09-15 15:50:01	2026-09-15 15:50:01	human	\N	\N
2	1	api_token.created	App\\Models\\User	2	{"name":"OpenClaw automation"}	2026-09-15 15:50:06	2026-09-15 15:50:06	human	\N	\N
3	1	api_token.revoked	App\\Models\\User	2	{"name":"OpenClaw automation"}	2026-09-15 15:50:10	2026-09-15 15:50:10	human	\N	\N
4	1	site_settings.updated	\N	\N	{"keys":["timezone","locale"]}	2026-09-16 09:52:34	2026-09-16 09:52:34	human	\N	\N
5	1	site_settings.updated	\N	\N	{"keys":["timezone","locale"]}	2026-09-16 17:52:36	2026-09-16 17:52:36	human	\N	\N
6	1	site_settings.updated	\N	\N	{"keys":["site_name","site_description","public_url","author_name"]}	2026-09-16 22:16:59	2026-09-16 22:16:59	human	\N	\N
7	\N	backup.completed	\N	\N	{"size_bytes":5118968}	2026-09-17 03:30:12	2026-09-17 03:30:12	system	Laravel Scheduler	\N
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: naslabs
--

COPY public.categories (id, name, slug, description, created_at, updated_at) FROM stdin;
1	Engineering	engineering	Software architecture, implementation notes, and practical engineering decisions.	2026-09-13 17:12:22	2026-09-15 13:03:52
2	Homelab	homelab	Self-hosted infrastructure, reliability experiments, and operations notes.	2026-09-13 17:12:22	2026-09-15 13:03:52
3	Data	data	Database design, data modeling, and data-intensive systems.	2026-09-13 17:12:22	2026-09-15 13:03:52
4	Learning	learning	Reading notes, experiments, and durable learning records.	2026-09-13 17:12:22	2026-09-15 13:03:52
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: naslabs
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	2026_01_01_000000_create_users_table	1
2	2026_01_01_000001_create_blog_tables	1
3	2026_01_02_000000_add_cover_image_alt_to_articles_table	2
4	2026_01_03_000000_add_role_to_users_table	3
5	2026_01_04_000000_create_site_settings_and_audit_logs_tables	4
6	2026_01_05_000000_create_api_tokens_table	5
7	2026_01_06_000000_create_service_accounts_table	6
8	2026_01_07_000000_add_review_requested_at_to_articles_table	7
9	2026_01_08_000000_add_avatar_path_to_users_table	7
10	2026_01_09_000000_add_scheduled_at_to_articles_table	7
11	2026_01_09_000001_add_actor_details_to_audit_logs_table	7
12	2026_01_10_000000_add_automation_and_seo_fields_to_articles_table	7
13	2026_01_11_000000_add_recovery_and_operational_indexes	8
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: naslabs
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: service_accounts; Type: TABLE DATA; Schema: public; Owner: naslabs
--

COPY public.service_accounts (id, name, slug, description, content_user_id, enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: naslabs
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
\.


--
-- Data for Name: site_settings; Type: TABLE DATA; Schema: public; Owner: naslabs
--

COPY public.site_settings (id, key, value, created_at, updated_at) FROM stdin;
1	timezone	Asia/Makassar	2026-09-16 09:52:34	2026-09-16 09:52:34
2	locale	id	2026-09-16 09:52:34	2026-09-16 09:52:34
3	site_name	NasLabs Journal	2026-09-16 22:16:59	2026-09-16 22:16:59
4	site_description	Personal engineering journal.	2026-09-16 22:16:59	2026-09-16 22:16:59
5	public_url	https://blog.naslabs.my.id	2026-09-16 22:16:59	2026-09-16 22:16:59
6	author_name	NasLabs Admin	2026-09-16 22:16:59	2026-09-16 22:16:59
7	backup_last_success_at	2026-09-17T03:30:12+00:00	2026-09-17 03:30:12	2026-09-17 03:30:12
8	backup_last_size_bytes	5118968	2026-09-17 03:30:12	2026-09-17 03:30:12
9	backup_last_failure_at	\N	2026-09-17 03:30:12	2026-09-17 03:30:12
10	scheduler_last_heartbeat_at	2026-09-17T12:32:47+08:00	2026-09-17 12:32:47	2026-09-17 12:32:47
11	scheduler_last_publish_run_at	2026-09-17T12:32:47+08:00	2026-09-17 12:32:47	2026-09-17 12:32:47
12	scheduler_last_publish_count	0	2026-09-17 12:32:47	2026-09-17 12:32:47
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: naslabs
--

COPY public.tags (id, name, slug, created_at, updated_at) FROM stdin;
1	Laravel	laravel	2026-09-13 17:15:53	2026-09-13 17:15:53
2	PostgreSQL	postgresql	2026-09-13 17:15:53	2026-09-13 17:15:53
3	Linux	linux	2026-09-13 17:15:53	2026-09-13 17:15:53
4	Docker	docker	2026-09-13 17:15:53	2026-09-13 17:15:53
5	Observability	observability	2026-09-13 17:15:53	2026-09-13 17:15:53
6	Clean Code	clean-code	2026-09-13 17:15:53	2026-09-13 17:15:53
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: naslabs
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at, role, avatar_path) FROM stdin;
1	NasLabs Admin	admin@naslabs.my.id	\N	$2y$12$MUls0anvmUD4yaGNoo7XueVvguCycHrNGKzKcvGNZFfzyx32/kq4q	\N	2026-09-13 17:12:22	2026-09-13 17:12:22	administrator	\N
2	OpenClaw Automation	openclaw@naslabs.my.id	\N	$2y$12$reGC4P3.SFLOz02V..hTmu3amEBk29VFpGe/0rE4ADOTB8nXwt0VG	\N	2026-09-15 15:50:01	2026-09-15 15:50:01	editor	\N
\.


--
-- Name: api_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: naslabs
--

SELECT pg_catalog.setval('public.api_tokens_id_seq', 1, true);


--
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: naslabs
--

SELECT pg_catalog.setval('public.articles_id_seq', 7, true);


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: naslabs
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 7, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: naslabs
--

SELECT pg_catalog.setval('public.categories_id_seq', 4, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: naslabs
--

SELECT pg_catalog.setval('public.migrations_id_seq', 13, true);


--
-- Name: service_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: naslabs
--

SELECT pg_catalog.setval('public.service_accounts_id_seq', 1, false);


--
-- Name: site_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: naslabs
--

SELECT pg_catalog.setval('public.site_settings_id_seq', 12, true);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: naslabs
--

SELECT pg_catalog.setval('public.tags_id_seq', 6, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: naslabs
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: api_tokens api_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_pkey PRIMARY KEY (id);


--
-- Name: api_tokens api_tokens_token_hash_unique; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_token_hash_unique UNIQUE (token_hash);


--
-- Name: article_tag article_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.article_tag
    ADD CONSTRAINT article_tag_pkey PRIMARY KEY (article_id, tag_id);


--
-- Name: articles articles_pkey; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_pkey PRIMARY KEY (id);


--
-- Name: articles articles_slug_unique; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_slug_unique UNIQUE (slug);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: categories categories_slug_unique; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_slug_unique UNIQUE (slug);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: service_accounts service_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.service_accounts
    ADD CONSTRAINT service_accounts_pkey PRIMARY KEY (id);


--
-- Name: service_accounts service_accounts_slug_unique; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.service_accounts
    ADD CONSTRAINT service_accounts_slug_unique UNIQUE (slug);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: site_settings site_settings_key_unique; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_key_unique UNIQUE (key);


--
-- Name: site_settings site_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.site_settings
    ADD CONSTRAINT site_settings_pkey PRIMARY KEY (id);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tags tags_slug_unique; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_slug_unique UNIQUE (slug);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: api_tokens_expires_at_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX api_tokens_expires_at_index ON public.api_tokens USING btree (expires_at);


--
-- Name: api_tokens_service_account_id_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX api_tokens_service_account_id_index ON public.api_tokens USING btree (service_account_id);


--
-- Name: articles_published_at_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX articles_published_at_index ON public.articles USING btree (published_at);


--
-- Name: articles_review_requested_at_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX articles_review_requested_at_index ON public.articles USING btree (review_requested_at);


--
-- Name: articles_review_status_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX articles_review_status_index ON public.articles USING btree (review_status);


--
-- Name: articles_scheduled_at_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX articles_scheduled_at_index ON public.articles USING btree (scheduled_at);


--
-- Name: articles_status_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX articles_status_index ON public.articles USING btree (status);


--
-- Name: articles_status_published_at_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX articles_status_published_at_index ON public.articles USING btree (status, published_at);


--
-- Name: articles_status_scheduled_at_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX articles_status_scheduled_at_index ON public.articles USING btree (status, scheduled_at);


--
-- Name: audit_logs_actor_type_created_at_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX audit_logs_actor_type_created_at_index ON public.audit_logs USING btree (actor_type, created_at);


--
-- Name: audit_logs_actor_type_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX audit_logs_actor_type_index ON public.audit_logs USING btree (actor_type);


--
-- Name: audit_logs_event_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX audit_logs_event_index ON public.audit_logs USING btree (event);


--
-- Name: audit_logs_subject_type_subject_id_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX audit_logs_subject_type_subject_id_index ON public.audit_logs USING btree (subject_type, subject_id);


--
-- Name: service_accounts_enabled_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX service_accounts_enabled_index ON public.service_accounts USING btree (enabled);


--
-- Name: sessions_last_activity_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: sessions_user_id_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: users_role_index; Type: INDEX; Schema: public; Owner: naslabs
--

CREATE INDEX users_role_index ON public.users USING btree (role);


--
-- Name: api_tokens api_tokens_service_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_service_account_id_foreign FOREIGN KEY (service_account_id) REFERENCES public.service_accounts(id) ON DELETE SET NULL;


--
-- Name: api_tokens api_tokens_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: article_tag article_tag_article_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.article_tag
    ADD CONSTRAINT article_tag_article_id_foreign FOREIGN KEY (article_id) REFERENCES public.articles(id) ON DELETE CASCADE;


--
-- Name: article_tag article_tag_tag_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.article_tag
    ADD CONSTRAINT article_tag_tag_id_foreign FOREIGN KEY (tag_id) REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: articles articles_category_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_category_id_foreign FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE SET NULL;


--
-- Name: articles articles_origin_service_account_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_origin_service_account_id_foreign FOREIGN KEY (origin_service_account_id) REFERENCES public.service_accounts(id) ON DELETE SET NULL;


--
-- Name: articles articles_reviewed_by_foreign; Type: FK CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_reviewed_by_foreign FOREIGN KEY (reviewed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: articles articles_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.articles
    ADD CONSTRAINT articles_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_foreign FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: service_accounts service_accounts_content_user_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: naslabs
--

ALTER TABLE ONLY public.service_accounts
    ADD CONSTRAINT service_accounts_content_user_id_foreign FOREIGN KEY (content_user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict CGpvFeLPhgiEbDHr3S43f6C3V0D3pDHBu0bhKOqc5oOgwGLzHMWpwuHWwTE1DGU

